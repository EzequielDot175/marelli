var HelloComponent = React.createClass({
	render: function(){
		return (
			<div>
				{this.props.name}
			</div>
			);
	}
});
